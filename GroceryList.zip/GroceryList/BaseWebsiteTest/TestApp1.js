$(document).ready(function(){
     $("#changingShit").text("Penis")
})